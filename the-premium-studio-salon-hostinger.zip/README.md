# The Premium Studio Salon — Hostinger Node.js package

This archive contains the already-built production website and a small Node.js
server. It has no runtime npm dependencies.

## Upload to Hostinger

1. Extract this ZIP so `package.json`, `server.js`, and the `dist` folder are
   together at the application root.
2. In hPanel, create a **Node.js web app** and upload the archive.
3. Use Node.js **22**. If asked to choose a framework, select **Other**.
4. Set the entry file to `server.js`. Leave the build command and output
   directory empty; the production files are already included.
5. Start the app with `npm start`. The server listens on Hostinger's `PORT`
   environment variable (or port 3000 when run locally).

Hostinger's current Node.js documentation:
- https://docs.hostinger.com/node.js/creating-an-app
- https://docs.hostinger.com/node.js/build-settings

## Before sharing the live site

The business details and contact links are included. The canonical URL, Open
Graph URL, sitemap, and robots file still use an example domain because the
final domain was not supplied. Update those URLs in:

- `dist/index.html`
- `dist/sitemap.xml`
- `dist/robots.txt`

The service suggestions are intentionally marked unconfirmed, and the gallery
images are illustrative style inspiration rather than actual salon work.
