import { createReadStream } from 'node:fs';
import { stat } from 'node:fs/promises';
import { createServer } from 'node:http';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const appDirectory = fileURLToPath(new URL('.', import.meta.url));
const publicDirectory = resolve(appDirectory, 'dist');
const rawPort = process.env.PORT || '3000';
const port = Number(rawPort);

if (!Number.isInteger(port) || port < 1 || port > 65535) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.ico': 'image/x-icon',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.txt': 'text/plain; charset=utf-8',
  '.webp': 'image/webp',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.xml': 'application/xml; charset=utf-8',
};

function sendText(response, statusCode, message) {
  response.writeHead(statusCode, {
    'Cache-Control': 'no-store',
    'Content-Type': 'text/plain; charset=utf-8',
    'X-Content-Type-Options': 'nosniff',
  });
  response.end(message);
}

async function findFile(pathname) {
  const segments = pathname.split('/').filter(Boolean);

  if (segments.some((segment) => segment === '..' || segment.includes('\0'))) {
    return { blocked: true };
  }

  let filePath = resolve(publicDirectory, ...segments);
  if (filePath !== publicDirectory && !filePath.startsWith(`${publicDirectory}${sep}`)) {
    return { blocked: true };
  }

  try {
    let fileInfo = await stat(filePath);
    if (fileInfo.isDirectory()) {
      filePath = join(filePath, 'index.html');
      fileInfo = await stat(filePath);
    }
    if (fileInfo.isFile()) return { filePath, fileInfo };
  } catch {
    // Missing extensionless paths are client-side routes; serve the app shell.
  }

  if (extname(pathname)) return { missing: true };

  const filePathFallback = join(publicDirectory, 'index.html');
  try {
    const fileInfo = await stat(filePathFallback);
    if (fileInfo.isFile()) return { filePath: filePathFallback, fileInfo };
  } catch {
    // The startup check below provides a clearer message if the bundle is absent.
  }

  return { missing: true };
}

const server = createServer(async (request, response) => {
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    response.setHeader('Allow', 'GET, HEAD');
    sendText(response, 405, 'Method not allowed');
    return;
  }

  let pathname;
  try {
    pathname = decodeURIComponent(new URL(request.url || '/', 'http://localhost').pathname);
  } catch {
    sendText(response, 400, 'Invalid request path');
    return;
  }

  const result = await findFile(pathname);
  if (result.blocked) {
    sendText(response, 403, 'Forbidden');
    return;
  }
  if (result.missing) {
    sendText(response, 404, 'Not found');
    return;
  }

  const { filePath, fileInfo } = result;
  const isAppShell = filePath === join(publicDirectory, 'index.html');
  response.writeHead(200, {
    'Cache-Control': isAppShell
      ? 'no-cache'
      : pathname.startsWith('/assets/')
        ? 'public, max-age=31536000, immutable'
        : 'public, max-age=3600',
    'Content-Length': fileInfo.size,
    'Content-Type': contentTypes[extname(filePath).toLowerCase()] || 'application/octet-stream',
    'X-Content-Type-Options': 'nosniff',
  });

  if (request.method === 'HEAD') {
    response.end();
    return;
  }

  const stream = createReadStream(filePath);
  stream.on('error', () => {
    if (!response.headersSent) sendText(response, 500, 'Unable to read requested file');
    else response.destroy();
  });
  stream.pipe(response);
});

try {
  await stat(join(publicDirectory, 'index.html'));
} catch {
  throw new Error('Production website files are missing. Upload the complete ZIP, including the dist folder.');
}

server.listen(port, '0.0.0.0', () => {
  console.info(`The Premium Studio Salon is serving on port ${port}`);
});
